<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $Title; ?></title>
        <link href="<?php echo base_url(); ?>assets/dist/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/build/css/custom.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/css/admin.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/css/sweetalert.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/css/cmxform.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/js/validation/resources/css/validation.css" rel="stylesheet" type="text/css"/>
        <script src="<?php echo base_url(); ?>assets/dist/vendors/jquery/dist/jquery.min.js"></script> 
    </head>

</head>
<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <div class="col-md-3 left_col menu_fixed">
                <div class="left_col scroll-view">
                    <div class="navbar nav_title" style="border: 0;">
                        <a href="<?php echo base_url(); ?>admin" class="site_title"> <span> Fog Cleaning </span></a>
                    </div>
                    <div class="clearfix"></div>
                    <?php $admin_detail = getLoginAdminDetails(); ?>
                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                        <div class="menu_section">
                            <ul class="nav side-menu">                          
                                <li><a href="<?php echo base_url(); ?>admin"> <i class="fa fa-home"></i>Dashboard</a></li>
                                <li><a><i class="fa fa-user"></i> User Management <span class="fa fa-chevron-down"></span></a>
                                    <ul class="nav child_menu">                      
                                        <li><a href="<?php echo base_url('admin/manage_client'); ?>">Client Management</a></li>
                                        <li><a href="<?php echo base_url('admin/manage_employee'); ?>">Employee Management</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo base_url('admin/manage_package'); ?>"> <i class="fa fa-dropbox"></i>Manage Package</a></li>
                                <li><a href="<?php echo base_url('admin/manage_booking'); ?>"> <i class="fa fa-th-list"></i> Manage Booking</a></li>
                                <li><a href="<?php echo base_url('admin/manage_cms'); ?>"> <i class="fa fa-pencil"></i> Manage CMS</a></li>
                                <li><a href="<?php echo base_url('admin/manage_report_an_issue'); ?>"> <i class="fa fa-bug"></i> Manage Reported Issues</a></li>
                                <li><a href="<?php echo base_url('admin/manage_review_rating'); ?>"> <i class="fa fa-star-o"></i> Manage Review Rating</a></li>
                                <li><a href="<?php echo base_url('admin/manage_promo_code'); ?>"> <i class="fa fa-tag"></i> Manage Promo Code</a></li>
                                <li><a href="<?php echo base_url('admin/manage_notification'); ?>"> <i class="fa fa-bell"></i> Manage Notifications</a></li>
                                <li><a href="<?php echo base_url('admin/app_setting'); ?>"> <i class="fa fa-gear"></i> Settings</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="top_nav">
                <div class="nav_menu">
                    <nav>
                        <div class="nav toggle">
                            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                        </div>
                        <ul class="nav navbar-nav navbar-right">
                            <li class="">
                                <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                    <img src="<?php echo base_url(); ?>assets/images/<?php if(isset($admin_detail->admin_image)){ echo $admin_detail->admin_image; } ?>" onerror="this.src='<?php echo base_url(); ?>assets/dist/images/user.png';">
                                    <?php echo $admin_detail->firstname . ' ' . $admin_detail->lastname; ?>
                                    <span class=" fa fa-angle-down"></span>
                                </a>
                                <ul class="dropdown-menu dropdown-usermenu pull-right">
                                    <li><a href="<?php echo base_url(); ?>admin/profile"> <i class="fa fa-user"></i> Profile</a></li>
                                    <li><a href="<?php echo base_url(); ?>admin/change_password"> <i class="fa fa-key"></i> Change Password</a></li>
                                    <li><a href="<?php echo base_url(); ?>admin/logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="right_col" role="main">
                <div class="row">       
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <?php
                            if (isset($error)) {
                                echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $error . '</div>';
                            } elseif ($this->session->flashdata('success')) {
                                echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $this->session->flashdata('success') . '</div>';
                            } elseif ($this->session->flashdata('error')) {
                                echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $this->session->flashdata('error') . '</div>';
                            } else {
                                echo validation_errors('<div class="alert alert-danger alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>', '</div>');
                            }
                            ?>