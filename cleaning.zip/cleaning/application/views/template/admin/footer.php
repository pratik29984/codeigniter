            </div>
        </div>
    </div>
</div>
<footer>
    <div class="pull-right">
        Fog Cleaning <a href="<?php echo base_url(); ?>">Web Application</a>
    </div>
    <div class="clearfix"></div>
</footer>
</div>
</div>

<script src="<?php echo base_url(); ?>assets/dist/js/ajaxFileUpload.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/datatables.net/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/select2/dist/js/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/iCheck/icheck.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/jquery.dataTables.delay.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/sweetalert.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/vendors/Chart.js/dist/Chart.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/build/js/custom.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/validation/resources/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/validation/init.js.php" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/validation/resources/lib/jquery.metadata.js" type="text/javascript"></script>
</body>
</html>