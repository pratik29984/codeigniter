<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- Meta, title, CSS, favicons, etc. -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Admin | Login </title>

        <link href="<?php echo base_url(); ?>assets/dist/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <?php echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>'; ?>
        <link href="<?php echo base_url(); ?>assets/dist/vendors/animate.css/animate.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/build/css/custom.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/css/admin.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/dist/js/validation/resources/css/validation.css" rel="stylesheet" type="text/css"/>
        <script src="<?php echo base_url(); ?>assets/dist/vendors/jquery/dist/jquery.min.js"></script> 
        <script src="<?php echo base_url(); ?>assets/dist/vendors/bootstrap/dist/js/bootstrap.min.js"></script> 
        <script src="<?php echo base_url(); ?>assets/dist/js/validation/resources/jquery.validate.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/dist/js/validation/init.js.php" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/dist/js/validation/resources/lib/jquery.metadata.js" type="text/javascript"></script>
    </head>
    <body class="login">
        <div>
            <a class="hiddenanchor" id="signup"></a>
            <a class="hiddenanchor" id="signin"></a>
            <div class="login_wrapper">
                <div class="animate form login_form">
                    <span class="iv-logo"></span>
                    <section class="login_content">
                        <?php
                        if (isset($error)) {
                            echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $error . '</div>';
                        } elseif ($this->session->flashdata('success')) {
                            echo '<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $this->session->flashdata('success') . '</div>';
                        } elseif ($this->session->flashdata('error')) {
                            echo '<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $this->session->flashdata('error') . '</div>';
                        } else {
                            echo validation_errors('<div class="alert alert-danger alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>', '</div>');
                        }
                        ?>
                        <form action="" class="validate" method="post">
                            <h1>Admin Login</h1>
                            <div>
                                <input type="text" name="email" value=""  class="form-control" placeholder="Email" required/>
                            </div>
                            <div>
                                <input type="password" value="" name="password" class="form-control" placeholder="Password" required />
                            </div>
                            <div>
                                <button type="submit" class="btn btn-default submit">Log in</button>
                                <a href="#signup" class="to_register"> Lost your password </a>
                            </div>
                            <div class="clearfix"></div>
                            <div class="separator">
                                <div class="clearfix"></div>
                                <div>
                                    <h1><i class="fa fa-paw"></i> Fog Cleaning</h1>
                                    <p class="text-center">©2017 All Rights Reserved. Fog Cleaning</p>
                                </div>
                            </div>
                        </form>
                    </section>
                </div>

                <div id="register" class="animate form registration_form">
                    <section class="login_content">
                        <form action="<?php echo base_url('admin/forgot_password'); ?>" method="post" class="validate">
                            <h1>Forgot Password</h1>
                            <div>
                                <input type="text" class="form-control" name="email" id="email" placeholder="Enter email" required="" />
                            </div>
                            <div>
                                <button type="submit" id="forgetsubmit"  class="btn btn-primary btn-block btn-flat submit">Submit</button>
                            </div>
                            <div class="clearfix"></div>
                            <div class="separator">
                                <p class="change_link">
                                    or <a href="#signin" class="to_register"> Log in </a>
                                </p>
                                <div class="clearfix"></div>
                                <br />
                                <div>
                                    <h1><i class="fa fa-paw"></i> Fog Cleaning!</h1>
                                    <p class="text-center">©2017 All Rights Reserved. Fog Cleaning</p>
                                </div>
                            </div>
                        </form>
                        <button id="my-btn" data-toggle="modal" data-target="#myModal" style="display:none;"></button>
                    </section>
                </div>
            </div>
        </div>
    </body>
</html>