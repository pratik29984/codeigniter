<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>

<div class="x_content">
    <div class="col-md-8 col-xs-12">
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="firstname">Firstname :  <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $User->firstname; ?>
            </div>
            <div class="clearfix"></div>
        </div>


        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="lastname">Lastname : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $User->lastname; ?>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone Number : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $User->phone; ?>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $User->email; ?>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php if ($this->uri->segment(3) == '1') { ?>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address : <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php echo $User->address; ?>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="zip_code">Zipcode : <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php echo $User->zip_code; ?>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php } else { ?>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="age">Date of Birth : <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php echo $User->dob; ?>
                </div>
                <div class="clearfix"></div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="experience">Experience : <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php echo $User->experience; ?>
                </div>
                <div class="clearfix"></div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="about_me">About Me : <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php echo $User->about_me; ?>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php } ?>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo ($User->status == 1) ? "Active" : "Deactive"; ?>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name">Profile Picture :</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <img class="img-circle" height="100" width="100" id="" onerror="this.src='<?php echo base_url(); ?>assets/dist/images/user.png'" src="<?php echo base_url('assets/images/') . $User->profile_picture; ?>">
            </div>
            <div class="clearfix"></div>
        </div>

    </div>
    <div class="form-group">
        <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
            <a href='#' onclick="history.back();" class="btn btn-primary">Back</a>
        </div>
    </div>
</div>