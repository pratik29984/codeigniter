<?php  get_instance()->load->library('settings'); ?>
<div class="x_title">
    <h2>Settings</h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="<?php echo base_url('admin/save_settings');?>" method="post" name="change_password">
        <!-- <div class="form-group">
            <label for="paypal_email" class="control-label col-md-3 col-sm-3 col-xs-12">Paypal Email</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('paypal_email'); ?>" type="text" name="paypal_email">
            </div>
        </div> -->

        <div class="form-group">
            <div class="control-label col-md-3 col-sm-3 col-xs-12"><h2><strong>Email Details</strong></h2></div>
        </div>

        <div class="form-group">
            <label for="mail_sent_name" class="control-label col-md-3 col-sm-3 col-xs-12">Mail Sent Name</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('mail_sent_name'); ?>" type="text" name="mail_sent_name" required>
            </div>
        </div>

        <div class="form-group">
            <label for="mail_from" class="control-label col-md-3 col-sm-3 col-xs-12">Email From</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('email_from'); ?>" type="text" name="email_from">
            </div>
        </div>

        <div class="form-group">
            <hr/>
            <div class="control-label col-md-3 col-sm-3 col-xs-12"><h2><strong>Paypal Details</strong></h2></div>
        </div>

        <div class="form-group">
            <label for="mail_from" class="control-label col-md-3 col-sm-3 col-xs-12">API Username</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('api_username'); ?>" type="text" name="api_username">
            </div>
        </div>

        <div class="form-group">
            <label for="mail_from" class="control-label col-md-3 col-sm-3 col-xs-12">API Password</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('api_password'); ?>" type="text" name="api_password">
            </div>
        </div>

        <div class="form-group">
            <label for="mail_from" class="control-label col-md-3 col-sm-3 col-xs-12">API Signature</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('api_signature'); ?>" type="text" name="api_signature">
            </div>
        </div>

        <div class="form-group">
            <hr/>
            <div class="control-label col-md-3 col-sm-3 col-xs-12"><h2><strong>Address API Detail</strong></h2></div>
        </div>

        <div class="form-group">
            <label for="mail_from" class="control-label col-md-3 col-sm-3 col-xs-12">API Key</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo $this->settings->getValue('address_api_key'); ?>" type="text" name="address_api_key">
            </div>
        </div>

        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </div>
    </form>
</div>