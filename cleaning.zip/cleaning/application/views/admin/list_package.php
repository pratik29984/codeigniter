<div class="x_title">
    <h2><i class="fa fa-list"></i> Package List</h2>
    <h2 style="float:right"><a class="btn btn-success btn-xs" href="<?php echo base_url(); ?>admin/add_package"><i class="fa fa-plus"></i> Add New Package</a></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="package_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Package Title</th>
                    <th>Package Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<form name="delete_package" method="post" action="<?php echo base_url('admin/delete_package'); ?>">
    <input type="hidden" name="delete_id" value="">
</form>
<script>
    $(document).ready(function ()
    {
        var dataTable = $('#package_table').DataTable( {
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_package")?>',
                type: "post", 
            },
            "aoColumns": [
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        });
    });

    function delete_package(id)
    {
        swal({
            title: "Are you sure?",
            text: "Do you want to delete package",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: false
        },
        function () {
            $('input[name=delete_id]').val(id);
            $('form[name=delete_package]').submit();
        });
    }
</script>