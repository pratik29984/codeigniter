<div class="x_title">
    <h2><i class="fa fa-list"></i> Pending Request List</h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="booking_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Package Name</th>
                    <th>Booking Date Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div class="x_title">
    <h2><i class="fa fa-list"></i> Assigned Request List</h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="booking_table2" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Package Name</th>
                    <th>Booking Date Time</th>
                    <th>Employee</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form-horizontal form-label-left validate" action="" method="post" name="assign_employee" id="assign_employee">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Assign Employee</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="employee_id">Employee<span class="required">*</span></label>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                            <select name="employee_id" id="employee_id" class="form-control" required>
                                <option value="">Select Employee</option>
                                <?php
                                $booked = '';
                                foreach ($employee as $value) {
                                    $booked = '<table class="table table-striped table-bordered no-footer" border="1">';
                                    if (isset($value['datetime'])) {
                                        $booked.='<tr><th>Booked Date</th><th>Client</th></tr>';
                                        $explode = explode(",", $value['datetime']);
                                        foreach ($explode as $val) {
                                            $booked.='<tr>';
                                            $exp = explode("=", $val);
                                            foreach ($exp as $k => $val2) {
                                                if ($k == 0) {
                                                    $val2 = date('d-m-Y h:i A', strtotime($val2));
                                                }
                                                $booked.='<td>' . $val2 . '</td>';
                                            }
                                            $booked.='</tr>';
                                        }
                                    } else {
                                        $booked.='<tr><td><center>Not assign any request.</center></td></tr>';
                                    }
                                    $booked . '</table>';
                                    ?>
                                    <option value="<?php echo $value['id']; ?>" title="<?php echo htmlentities($booked); ?>"><?php echo $value['firstname'] . " " . $value['lastname']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class='clearfix'></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id" id='booking_id'/>
                    <button type="submit" class="btn btn-success">Submit</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="x_title">
    <h2><i class="fa fa-list"></i> User Register In Last 15 Days</h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <canvas id="canvas"></canvas>
</div>

<script>
    $(document).ready(function ()
    {
        $('#booking_table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_request/pending")?>',
                type: "post", 
            },
            "aoColumns": [  
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                { "bVisible": true, "bSearchable": false, "bSortable": false }
            ]
        });

        $('#booking_table2').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_request/assigned")?>',
                type: "post", 
            },
            "aoColumns": [
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
            ]
        });

        $(document).on('click', '.assign', function () {
            $('#employee_id').select2();
            var id = $(this).data('id');
            var employee_id = ($(this).data('employee') != 0) ? $(this).data('employee') : "";
            $('#booking_id').val(id);
            if (employee_id) {
                $('option[value=' + employee_id + ']').attr("selected", "selected");
            } else {
                $('option[value=""]').attr("selected", "selected");
            }
            $('#myModal').modal('show');
        });

        $('body').on('mouseenter', '.select2-results__option', function (e) {
            var t = $(this);
            var title = t.attr('title');
            if (title) {
                t.attr('title', 'Assigned Request');
                t.data('content', title);
                t.popover({placement: 'auto', trigger: 'hover', html: true});
            }
        });
    });

        var chart_data = $.parseJSON('<?php echo $chart_data; ?>'); 
        var randomScalingFactor = function() {
            return Math.round(Math.random() * 100);
        };
        var randomColorFactor = function() {
            return Math.round(Math.random() * 255);
        };
        var randomColor = function(opacity) {
            return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
        };
        var config = {
            type: 'line',
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [{
                    label: "Client",
                    data: chart_data.client,
                    fill: false,
                },
                {
                    label: "Employee",
                    data: chart_data.employee,
                    fill: false,
                }
                ]
            },
            options: {
                responsive: true,
                hover: {
                    mode: 'label'
                },
                scales: {
                    xAxes: [{
                        type: 'time',
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Date'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'No. of Users'
                        },
                        ticks: {
                            min:0,
                        }
                    }]
                },
                title: {
                    display: true,
                    text: 'Users'
                }
            }
        };

        $.each(config.data.datasets, function(i, dataset) {
            dataset.borderColor = randomColor(0.4);
            dataset.backgroundColor = randomColor(0.5);
            dataset.pointBorderColor = randomColor(0.7);
            dataset.pointBackgroundColor = randomColor(0.5);
            dataset.pointBorderWidth = 1;
        });

        window.onload = function() {
            var ctx = document.getElementById("canvas").getContext("2d");
            window.myLine = new Chart(ctx, config);
        };
    </script>