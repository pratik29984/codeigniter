<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>

<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  enctype='multipart/form-data'>
        <div class="col-md-8 col-xs-12">
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="client_id">Client<span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php if(isset($data)){ foreach ($client as $value) { if($data->client_id == $value['id']){ ?>
                    <input type="text" class="form-control" value="<?php echo $value['firstname'] . " " . $value['lastname']; ?>" readonly>
                    <?php }} }else{ ?>
                    <select name="client_id" class="form-control" required>
                        <option value="">Select Client</option>
                        <?php foreach ($client as $value) { ?>
                            <option value="<?php echo $value['id']; ?>" <?php echo set_select('client_id', $value['id'], (!empty($data) && $data->client_id == $value['id'] ? TRUE : FALSE)); ?>><?php echo $value['firstname'] . " " . $value['lastname']; ?></option>
                        <?php } ?>
                    </select>
                    <?php } ?>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="package_id">Package<span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select name="package_id" class="form-control" required>
                        <option value="">Select Package</option>
                        <?php foreach ($packages as $value) { ?>
                            <option value="<?php echo $value['id']; ?>" <?php echo set_select('package_id', $value['id'], (!empty($data) && $data->package_id == $value['id'] ? TRUE : FALSE)); ?>><?php echo $value['title']; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="datetime">Booking Date Time <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control datetime" id="myDatepicker" value="<?php echo set_value('datetime', isset($data->datetime)? date('d-m-Y h:i A', strtotime($data->datetime)):""); ?>" name="datetime" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="datetime">Amount <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="number" class="form-control" value="<?php echo set_value('amount', isset($data->amount)? $data->amount:""); ?>" name="amount" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_firstname">First Name <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('request_firstname', isset($data->request_firstname)? $data->request_firstname:""); ?>" name="request_firstname">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_lastname">Last Name <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('request_lastname', isset($data->request_lastname)? $data->request_lastname:""); ?>" name="request_lastname">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_email">Email <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="email" class="form-control" value="<?php echo set_value('request_email', isset($data->request_email)? $data->request_email:""); ?>" name="request_email">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_phone">Phone <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('request_phone', isset($data->request_phone)? $data->request_phone:""); ?>" name="request_phone">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_address">Address <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input id="autocomplete" placeholder="Enter your address" type="text" class="form-control" value="<?php echo set_value('request_address', isset($data->request_address)? $data->request_address:""); ?>" name="request_address"  autocomplete="off">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_zipcode">Zipcode <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input id="zipcode" type="text" class="form-control" value="<?php echo set_value('request_zipcode', isset($data->request_zipcode)? $data->request_zipcode:""); ?>" name="request_zipcode">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href='<?php echo base_url(); ?>admin/manage_booking' class="btn btn-primary">Cancel</a>
            </div>
        </div>
    </form>
</div>
<script>
    $(document).ready(function () {
        $('#myDatepicker').datetimepicker({
            sideBySide: true,
            format: 'DD-MM-YYYY hh:mm A',
            <?php if(!isset($data)){ ?>
            minDate: new Date()
            <?php } ?>
        });
    });

    var autocomplete;
    function initAutocomplete() {        
        autocomplete = new google.maps.places.Autocomplete(
            (document.getElementById('autocomplete')),
            {types: ['geocode']});
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        var place = autocomplete.getPlace();
        if(place.address_components[5]){
            $('#zipcode').val(place.address_components[5].long_name);
        }
    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $this->settings->getValue('address_api_key'); ?>&libraries=places&callback=initAutocomplete"
        async defer></script>