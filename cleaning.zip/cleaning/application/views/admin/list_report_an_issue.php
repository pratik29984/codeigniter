<div class="x_title">
    <h2><i class="fa fa-list"></i> Reported Issues</h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="report_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<form name="delete_report_an_issue" method="post" action="<?php echo base_url('admin/delete_report_an_issue'); ?>">
    <input type="hidden" name="delete_id" value="">
</form>
<script>
    $(document).ready(function ()
    {
        var dataTable = $('#report_table').DataTable( {
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_report_an_issue")?>',
                type: "post", 
            },
            "aoColumns": [
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        });
    });

    function info(id)
    {
        var data = $('#data'+id).text();
        swal({
        title: "Description",
            text: String(data),
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Close",
            closeOnConfirm: false
        });
    }

    function delete_report_an_issue(id)
    {
        swal({
            title: "Are you sure?",
            text: "Do you want to delete report an issue",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: false
        },
        function () {
            $('input[name=delete_id]').val(id);
            $('form[name=delete_report_an_issue]').submit();
        });
    }
</script>