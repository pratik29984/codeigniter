<div class="x_title">
    <h2><i class="fa fa-list"></i> Notification List</h2>    
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Key</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $value) { ?>
                    <tr>
                        <td><?php echo $value['id']; ?></td>
                        <td><?php echo ucwords(str_replace('_',' ',$value['key'])); ?></td>
                        <td><a class='btn btn-default btn-xs' href="<?php echo base_url('admin/edit_notification/' . $value['id']); ?>"><i class="fa fa-edit"></i></a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $(document).ready(function ()
    {
        var dataTable = $('#table').DataTable( {
            "processing": true,
            "iDisplayLength": 10,
            "aaSorting": [[0, 'asc']],
            "aoColumns": [
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        });
    });
</script>