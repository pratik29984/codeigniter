<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>

<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  enctype='multipart/form-data' id="package">

        <div class="col-md-8 col-xs-12">
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="client_id">Client<span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select id="client_id" name="client_id" class="form-control" required>
                        <option value="">Select Client</option>
                        <?php foreach ($client as $value) { ?>
                            <option value="<?php echo $value['id']; ?>" <?php echo set_select('client_id'); ?>><?php echo $value['firstname'] . " " . $value['lastname']; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="employee_id">Employee<span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select id="employee_id" name="employee_id" class="form-control" required>
                        <option value="">Select Employee</option>
                        <?php foreach ($employee as $value) { ?>
                            <option value="<?php echo $value['id']; ?>" <?php echo set_select('employee_id'); ?>><?php echo $value['firstname'] . " " . $value['lastname']; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="form-group hide">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="request_id">Request<span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select id="request_id" name="request_id" class="form-control" required>
                        <option value="">Select Request</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="review">Review <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <textarea name="review" class="form-control" required><?php echo set_value('review'); ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rating">Rating <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div id="rateYo"></div>
                    <input type="hidden" class="form-control" value="" name="rating" id="rating" required>
                </div>
            </div>
            
        </div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href='<?php echo base_url('admin/manage_package'); ?>' class="btn btn-primary">Cancel</a>
            </div>
        </div>

    </form>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $("#rateYo").rateYo({
            maxValue: 5,
            numStars: 5,
            fullStar: true,
            starWidth: "25px"
          }).on("rateyo.set", function (e, data) {
              $('#rating').val(data.rating);
          });;
        $('#client_id,#employee_id').on('change',function(){
            var client_id = $('#client_id').val();
            var employee_id = $('#employee_id').val();
            if(client_id!='' && employee_id!=''){
                $.ajax({
                    type: "post",
                    url: '<?php echo base_url("admin/get_client_employee_booking") ?>',
                    data: 'client_id='+client_id+'&employee_id='+employee_id,
                    success: function (response)
                    {
                        var res = $.parseJSON(response);
                        console.log(res);
                        var html = '<option value="">Select Request</option>';
                        $.each(res, function(key,value) {
                          html += '<option value="'+value.id+'">'+value.title+'</option>';
                        });
                        $('#request_id').parent().parent().removeClass('hide');
                        $('#request_id').html(html);
                    }
                });
            }
        });        
    });
</script>    
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>