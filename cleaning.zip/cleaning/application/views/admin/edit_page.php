<script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  id="page">

        <div class="col-md-8 col-xs-12">

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Title <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('title', $data->title); ?>" name="title" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="content">Content <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <textarea name="content" class="form-control" id="content" required rows="8"><?php echo set_value('content', $data->content); ?></textarea>
                </div>
            </div>

        </div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href='<?php echo base_url('admin/manage_cms'); ?>' class="btn btn-primary">Cancel</a>
            </div>
        </div>

    </form>
</div>
<script>
    CKEDITOR.replace('content');
</script>