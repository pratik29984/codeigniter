<script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  id="page">

        <div class="col-md-12 col-xs-12">

            <div class="form-group">
                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subject">Subject <span class="required">*</span></label>
                <div class="col-md-10 col-sm-10 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('subject', $data->subject); ?>" name="subject" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="content">Content <span class="required">*</span></label>
                <div class="col-md-10 col-sm-10 col-xs-12">
                    <textarea name="content" class="form-control" id="content" required rows="8"><?php echo $notification_template; ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-2 col-sm-2 col-xs-12 text-right" for="content">Note</div>
                <div class="col-md-10 col-sm-10 col-xs-12">
                    <?php if($data->key=='forgot_password'){ ?>
                    <div>First Name: {{firstname}}</div>
                    <div>Password: {{password}}</div>
                    <?php } if($data->key=='verification'){ ?>
                    <div>FirstName: {{firstname}}</div>
                    <div>Site Name: {{site_name}}</div>
                    <div>Verification Code: {{verification_code}}</div>
                    <?php } if($data->key=='signup'){ ?>
                    <div>First Name: {{firstname}}</div>
                    <div>Site Name: {{site_name}}</div>
                    <div>Email: {{email}}</div>
                    <?php } if($data->key=='booking'){ ?>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Client Last Name: {{lastname}}</div>
                    <div>Client Address: {{address}}</div>
                    <div>Client Zipcode: {{zipcode}}</div>
                    <div>Client Email: {{email}}</div>
                    <div>Client Phone Number: {{phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='booking_accepted_client_mail'){ ?>
                    <div>Admin First Name: {{admin_firstname}}</div>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Employee Last Name: {{employee_lastname}}</div>
                    <div>Employee Email: {{employee_email}}</div>
                    <div>Employee Phone Number: {{employee_phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='booking_cancel_admin_mail'){ ?>
                    <div>Admin First Name: {{admin_firstname}}</div>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Client Last Name: {{lastname}}</div>
                    <div>Client Address: {{address}}</div>
                    <div>Client Zipcode: {{zipcode}}</div>
                    <div>Client Email: {{email}}</div>
                    <div>Client Phone Number: {{phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='booking_cancel_client_mail'){ ?>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='booking_rejected_admin_mail'){ ?>
                    <div>Admin First Name: {{admin_firstname}}</div>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Client Last Name: {{lastname}}</div>
                    <div>Client Address: {{address}}</div>
                    <div>Client Zipcode: {{zipcode}}</div>
                    <div>Client Email: {{email}}</div>
                    <div>Client Phone Number: {{phone}}</div>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Employee Last Name: {{employee_lastname}}</div>
                    <div>Employee Email: {{employee_email}}</div>
                    <div>Employee Phone Number: {{employee_phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='process_start'){ ?>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Employee Last Name: {{employee_lastname}}</div>
                    <div>Employee Email: {{employee_email}}</div>
                    <div>Employee Phone Number: {{employee_phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } if($data->key=='process_completed'){ ?>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Employee Last Name: {{employee_lastname}}</div>
                    <div>Employee Email: {{employee_email}}</div>
                    <div>Employee Phone Number: {{employee_phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Transaction Id: {{transaction_id}}</div>
                    <div>Amount: {{amount}}</div>
                    <div>Total Time: {{total_time}}</div>
                    <?php } if($data->key=='review'){ ?>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Client Last Name: {{lastname}}</div>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Review: {{review}}</div>
                    <div>Rating: {{rating}}</div>
                    <?php } if($data->key=='add_client_mail' || $data->key=='add_employee_mail'){ ?>
                    <div>First Name: {{firstname}}</div>
                    <div>Site Name: {{site_name}}</div>
                    <div>Email: {{email}}</div>
                    <div>Password: {{password}}</div>
                    <?php } if($data->key=='employee_assigned'){ ?>
                    <div>Employee First Name: {{employee_firstname}}</div>
                    <div>Client First Name: {{firstname}}</div>
                    <div>Client Last Name: {{lastname}}</div>
                    <div>Client Address: {{address}}</div>
                    <div>Client Zipcode: {{zipcode}}</div>
                    <div>Client Email: {{email}}</div>
                    <div>Client Phone Number: {{phone}}</div>
                    <div>Booking Date: {{booking_date}}</div>
                    <div>Package Title: {{package_title}}</div>
                    <div>Amount: {{amount}}</div>
                    <?php } ?>
                </div>
            </div>

        </div>
        <div class="form-group">
            <div class="col-md-2"></div>
            <div class="col-md-8 col-sm-8 col-xs-12 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href='<?php echo base_url('admin/manage_notification'); ?>' class="btn btn-primary">Cancel</a>
            </div>
        </div>

    </form>
</div>
<script>
    CKEDITOR.replace('content');
    CKEDITOR.config.contentsCss = "<?php echo base_url('assets/dist/css/admin.css'); ?>";
    CKEDITOR.config.height = '400px';
    CKEDITOR.config.allowedContent=true;
</script>