<script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>

<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  enctype='multipart/form-data' id="package">

        <div class="col-md-8 col-xs-12">

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Package Title <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('title', isset($data->title))?$data->title:""; ?>" name="title" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Package Description <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <textarea name="description" class="form-control" required><?php echo set_value('description', isset($data->description)?$data->description:""); ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price">Package Price <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="number" class="form-control" value="<?php echo set_value('price', isset($data->price)?$data->price:""); ?>" name="price" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="currency">Currency <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <select name="currency" class="form-control" required>
                        <option value="">Select Currency</option>
                        <option value="$" <?php echo set_select('currency', "$", (!empty($data) && $data->currency == "$" ? TRUE : FALSE)); ?>>$</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="logo">Logo <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="file" name="logo" class="form-control col-md-7 col-xs-12" id="logo">
                </div>
            </div>

            <?php if (isset($data->logo)) { ?>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="logo"><span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <img class="img-circle" height="100" width="100" src="<?php echo base_url('assets/images/package/'.$data->id.'/logo_thumb/') . $data->logo; ?>">
                </div>
            </div>
            <?php } ?>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="logo">Images <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12"> 
                    <input type="file" name="imgs" multiple class="form-control col-md-7 col-xs-12" id="imgs">
                    <?php
                    if (isset($data->images) && $data->images!='') {
                        $exp = explode(',', $data->images);
                        if ($exp) {
                            foreach ($exp as $key => $value) {
                                $type = pathinfo(base_url('assets/images/package/'.$data->id.'/images/') . $value, PATHINFO_EXTENSION);
                                $data2 = file_get_contents(base_url('assets/images/package/'.$data->id.'/images/') . $value);
                                $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data2);
                                ?> 
                                <span id="pip<?php echo $key; ?>" class="pip">
                                    <input type="hidden" name="images[]" value="<?php echo $base64; ?>">
                                    <img class="img-circle imageThumb" src="<?php echo $base64; ?>" title="image">
                                    <span class="remove"><i class="fa fa-close"></i></span>
                                </span>
                            <?php
                            }
                        }
                    }
                    ?>
                </div>
            </div>

        </div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>
                <a href='<?php echo base_url('admin/manage_package'); ?>' class="btn btn-primary">Cancel</a>
            </div>
        </div>

    </form>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        CKEDITOR.replace('description');
        if (window.File && window.FileList && window.FileReader) {
            var str = '';
            $("#imgs").on("change", function (e) {
                var files = e.target.files,
                        filesLength = files.length;
                var j = 0;
                for (var i = 0; i < filesLength; i++) {
                    var f = files[i];
                    var fileReader = new FileReader();
                    fileReader.onload = (function (e) {
                        var file = e.target;
                        $("<span id=\"pip" + j + "\" class=\"pip\">" +
                                "<input type=\"hidden\" name=\"images[]\" value=\"" + e.target.result + "\">" +
                                "<img class=\"img-circle imageThumb\" src=\"" + e.target.result + "\" title=\"image\"/>" +
                                "<span class=\"remove\"><i class=\"fa fa-close\"></i></span>" +
                                "</span>").insertAfter("#imgs").parent();

                        j++;
                    });
                    fileReader.readAsDataURL(f);
                }
            });
        }
        $(".form-group").on("click",".remove", function (e) {
            $(this).parent(".pip").remove();
        });
    });
</script>    