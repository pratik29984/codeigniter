<div class="x_title">
    <h2><i class="fa fa-list"></i> Booking List</h2>
    <h2 style="float:right"><a class="btn btn-success btn-xs" href="<?php echo base_url(); ?>admin/add_booking"><i class="fa fa-plus"></i> Add New Booking</a></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="booking_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Package Name</th>
                    <th>Booking Date Time</th>
                    <th>Employee</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <form class="form-horizontal form-label-left validate" action="" method="post" name="assign_booking" id="assign_booking">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Assign Employee</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="employee_id">Employee<span class="required">*</span></label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                                <select name="employee_id" id="employee_id" class="form-control" required>
                                    <option value="">Select Employee</option>
                                    <?php
                                    $booked = '';
                                    foreach ($employee as $value) {
                                        $booked = '<table class="table table-striped table-bordered no-footer" border="1">';
                                        if (isset($value['datetime'])) {
                                            $booked.='<tr><th>Booked Date</th><th>Client</th></tr>';
                                            $explode = explode(",", $value['datetime']);
                                            foreach ($explode as $val) {
                                                $booked.='<tr>';
                                                $exp = explode("=", $val);
                                                foreach ($exp as $k => $val2) {
                                                    if ($k == 0) {
                                                        $val2 = date('d-m-Y h:i A', strtotime($val2));
                                                    }
                                                    $booked.='<td>' . $val2 . '</td>';
                                                }
                                                $booked.='</tr>';
                                            }
                                        } else {
                                            $booked.='<tr><td><center>Not assign any request.</center></td></tr>';
                                        }
                                        $booked . '</table>';
                                        ?>
                                        <option value="<?php echo $value['id']; ?>" title="<?php echo htmlentities($booked); ?>"><?php echo $value['firstname'] . " " . $value['lastname']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class='clearfix'></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="id" id='booking_id'/>
                        <button type="submit" class="btn btn-success">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<form name="delete_booking" method="post" action="<?php echo base_url('admin/delete_booking'); ?>">
    <input type="hidden" name="delete_id" value="">
</form>
<script>
    $(document).ready(function ()
    {
        var dataTable = $('#booking_table').DataTable( {
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_booking")?>',
                type: "post", 
            },
            "aoColumns": [
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        });

        $(document).on('click', '.assign', function () {
            $('#employee_id').select2();
            var id = $(this).data('id');
            var booking_id = ($(this).data('booking') != 0) ? $(this).data('booking') : "";
            $('#booking_id').val(id);

            if (booking_id) {
                $('option[value=' + booking_id + ']').attr("selected", "selected");
            } else {
                $('option[value=""]').attr("selected", "selected");
            }
            $('#myModal').modal('show');
        });

        $('body').on('mouseenter', '.select2-results__option', function (e) {
            var t = $(this);
            var title = t.attr('title');
            if (title) {
                t.attr('title', 'Assigned Request');
                t.data('content', title);
                t.popover({placement: 'auto', trigger: 'hover', html: true});
            }
        });

    });

    function delete_booking(id)
    {
        swal({
            title: "Are you sure?",
            text: "Do you want to delete booking",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: false
        },
        function () {
            $('input[name=delete_id]').val(id);
            $('form[name=delete_booking]').submit();
        });
    }
</script>