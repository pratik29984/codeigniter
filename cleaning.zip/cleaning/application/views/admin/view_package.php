<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="col-md-8 col-xs-12">
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Package Title :  <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $data->title; ?>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Package Description : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $data->description; ?>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price">Package Price : <span class="required"></span></label>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $data->price; ?>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
            <a href='<?php echo base_url(); ?>admin/manage_package' class="btn btn-primary">Back</a>
        </div>
    </div>
</div>