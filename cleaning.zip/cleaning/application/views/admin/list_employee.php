<div class="x_title">
    <h2><i class="fa fa-list"></i> Manage Employee</h2>
    <h2 style="float:right"><a class="btn btn-success btn-xs" href="<?php echo base_url(); ?>admin/add_employee"><i class="fa fa-plus"></i> Add New Employee</a></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="user_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Average Rating</th>
                    <th>Created on</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<form name="delete_employee" method="post" action="<?php echo base_url('admin/delete_employee'); ?>">
    <input type="hidden" name="delete_id" value="">
</form>
<script type="text/javascript" language="javascript" >
    $(document).ready(function() {
        var dataTable = $('#user_table').DataTable( {
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_employee")?>',
                type: "post", 
            },
            "aoColumns": [
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": true, "bSortable": true},
            {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        });
    });
    function delete_employee(id)
    {
        swal({
            title: "Are you sure?",
            text: "Do you want to delete employee",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!",
            closeOnConfirm: false
        },
        function () {
            $('input[name=delete_id]').val(id);
            $('form[name=delete_employee]').submit();
        });
    }
</script>      
