<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>

<div class="x_content">
    <form class="form-horizontal form-label-left validate" action="" method="post" name="registration"  enctype='multipart/form-data'>
        <div class="col-md-8 col-xs-12">
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="firstname">Firstname <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('firstname', isset($User->firstname)?$User->firstname:""); ?>" name="firstname" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="lastname">Lastname <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('lastname', isset($User->lastname)?$User->lastname:""); ?>" name="lastname">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone Number <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('phone', isset($User->phone)?$User->phone:""); ?>" name="phone" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="text" class="form-control" value="<?php echo set_value('email', isset($User->email)?$User->email:""); ?>" name="email" required="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Password <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="password" class="form-control" value="<?php echo set_value('password'); ?>" name="password" id="password" <?php echo !isset($User->password)?"required":""; ?>>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cpassword">Confirm password <span class="required">*</span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input type="password" class="form-control" value="<?php echo set_value('cpassword'); ?>" name="cpassword" <?php echo !isset($User->password)?"required validate=\"{equalTo:'#password'}\"":""; ?>>
                </div>
            </div>

            <?php if ($this->uri->segment(2) == 'add_client') { ?>
                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address <span class="required"></span></label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <textarea name="address" class="form-control"><?php echo set_value('address', isset($User->address)?$User->address:""); ?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="zip_code">Zipcode <span class="required"></span></label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <input type="text" class="form-control" value="<?php echo set_value('zip_code', isset($User->zip_code)?$User->zip_code:""); ?>" name="zip_code">
                    </div>
                </div>
            <?php } else { ?>

                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="dob">Date of Birth <span class="required"></span></label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <input type="text" class="form-control date" id="myDatepicker" value="<?php echo set_value('dob', isset($User->dob)?date('m/d/Y', strtotime($User->dob)):''); ?>" name="dob">
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="experience">Experience <span class="required"></span></label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <input type="text" class="form-control" value="<?php echo set_value('experience', isset($User->experience)?$User->experience:""); ?>" name="experience">
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="about_me">About Me <span class="required"></span></label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <textarea name="about_me" class="form-control" rows="3"><?php echo set_value('about_me', isset($User->about_me)?$User->about_me:""); ?></textarea>
                    </div>
                </div>
            <?php } ?>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status <span class="required"></span></label>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <input class="flat" type="radio" name="status" value="enable" <?php echo set_radio('status', 'enable', isset($User->status)?(('enable' == $User->status) ? TRUE : FALSE):TRUE); ?>></span> Enable
                    <input class="flat" type="radio" name="status" value="disable" <?php echo set_radio('status', 'disable', isset($User->status)?(('disable' == $User->status) ? TRUE : FALSE):FALSE); ?>></span> Disable
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name">Profile picture <span class="required"></span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="file" name="profile_picture" class="form-control col-md-7 col-xs-12 add_image" id="admin_image_upload">
                </div>
            </div>
            <?php if(isset($User->profile_picture)){ ?>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name"></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <img class="img-circle" height="100" width="100" src="<?php echo base_url('assets/images/user/') . $User->profile_picture; ?>">
                </div>
            </div>
            <?php } ?>
        </div>
        <div class="form-group">
            <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-2 submit-cls">
                <button type="submit" class="btn btn-success">Submit</button>

                <a href='<?php echo ($this->uri->segment(2) == 'add_client')?base_url('admin/manage_client'):base_url('admin/manage_employee'); ?>' class="btn btn-primary">Cancel</a>
            </div>
        </div>

    </form>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#myDatepicker').datetimepicker({
            maxDate: new Date(),
            format: 'MM/DD/YYYY',
            useCurrent: false
        });
    });
</script>              