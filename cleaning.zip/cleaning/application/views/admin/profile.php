<div class="x_title">
    <h2>Edit Profile <small></small></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <form  class="form-horizontal form-label-left validate" enctype="multipart/form-data" action="" method="post" name="profile">
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name"></label>
        </div>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name">Username <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text" required="required" value="<?php echo $Admin->username; ?>" name="username" class="form-control col-md-7 col-xs-12">
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Firstname <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text" value="<?php echo $Admin->firstname; ?>" name="firstname" required="required"  class="form-control col-md-7 col-xs-12">
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Lastname <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text" value="<?php echo $Admin->lastname; ?>" name="lastname" required="required" class="form-control col-md-7 col-xs-12">
            </div>
        </div>

        <div class="form-group">
            <label for="email" class="control-label col-md-3 col-sm-3 col-xs-12">Email <span class="required">*</span></label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" value="<?php echo $Admin->email; ?>" type="email" name="email" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name">Profile Picture <span class="required">*</span></label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="file" name="admin_image" class="form-control col-md-7 col-xs-12">
            </div>
        </div>
        <?php if (!empty($Admin->admin_image)) { ?>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user-name"></label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <img class="img-circle" height="100" width="100" src="<?php echo base_url("assets/images/".$Admin->admin_image); ?>">
            </div>
        </div>
        <?php } ?>
        <div class="ln_solid"></div>
        <div class="form-group">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </div>
    </form>
</div>