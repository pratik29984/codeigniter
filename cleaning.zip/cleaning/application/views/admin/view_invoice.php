<div class="x_title">
    <h2><?php echo $Title; ?></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div id="print_invoice">
        <div class="col-xs-12 col-md-8 col-md-offset-2 print_invoice_width" style="border:1px solid #ddd; border-radius:3px;">
            <div class="invoice-title">
                    <h2>Invoice</h2>
                    <h2 class="pull-right">Fog Cleaning</h2>
            </div>
            <div class="clearfix"></div>
            <hr>
                <div class="col-xs-6">
                    <strong>Shipped To:</strong><br>
                        <?php echo $data->request_firstname.' '.$data->request_lastname; ?><br>
                        <?php if($data->request_email){ ?>
                        <?php echo $data->request_email; ?><br>
                        <?php } if($data->request_phone){ ?>
                        <?php echo $data->request_phone; ?><br>
                        <?php } if($data->request_address){ ?>
                        <?php echo $data->request_address; ?><br>
                        <?php } if($data->request_zipcode){ ?>
                        <?php echo $data->request_zipcode; ?><br>
                        <?php } ?><br>
                </div>
                <div class="col-xs-6 text-right">
                        <strong>Transaction ID:</strong><br>
                        <?php echo $data->transaction_id; ?><br><br>
                        <strong>Order Date:</strong><br>
                        <?php echo date('F j, Y'); ?><br><br>
                </div>

            <div class="clearfix"></div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><strong>Order summary</strong></h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                                        <td><strong>Package</strong></td>
                                        <td class="text-center"><strong>Price</strong></td>
                                        <td class="text-right"><strong>Total</strong></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo $data->title; ?></td>
                                        <td class="text-center"><?php echo $data->currency.$data->price; ?></td>
                                        <td class="text-right"><?php echo $data->currency.$data->price; ?></td>
                                    </tr>
                                    <?php $promo_amount=0; if($data->promo_code){ ?>
                                    <tr>
                                        <td>Promo Code: <?php echo $data->promo_code; ?></td>
                                        <td class="text-center"><?php $promo_amount = ($data->type=='flat')?$data->amount:(($data->amount / 100) * $data->price); echo $data->currency.$promo_amount; ?></td>
                                        <td class="text-right"><?php echo $data->currency.$promo_amount; ?></td>
                                    </tr>
                                    <?php } ?>
                                    <tr>
                                        <td class="thick-line"></td>
                                        <td class="thick-line text-center"><strong>Total</strong></td>
                                        <td class="thick-line text-right"><?php echo $data->currency.($data->price-$promo_amount); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <div class="form-group">
        <div class="col-xs-12 col-md-8 col-md-offset-2 text-right">
            <br>    
            <a href='#' class="btn btn-success print_invoice">Print</a>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('.print_invoice').on('click',function(){
            $('.print_invoice_width').css({'margin-left':'10%','width':'80%','border':'0','border-radius':'0'});
            $('.print_invoice,.nav_menu,.x_title,footer').hide();
            $('.x_panel').attr('style','border:0');
            window.print();
            $('.print_invoice_width').removeAttr('style');
            $('.print_invoice_width').css({'border':'1px solid #ddd','border-radius':'3px'});
            $('.print_invoice,.nav_menu,.x_title,footer').show();
            $('.x_panel').attr('style','border:1px solid #E6E9ED');
        });
    });
</script>