<div class="x_title">
    <h2>Change Password</h2>
    <div class="clearfix"></div>
</div>
<form class="form-horizontal form-label-left validate" action="" method="post" name="change_password">
    <div class="form-group">
        <label for="password" class="control-label col-md-3 col-sm-3 col-xs-12">Old password <span class="required">*</span></label>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo set_value('password'); ?>" type="password" name="old_password" required>
        </div>
    </div>    

    <div class="form-group">
        <label for="password" class="control-label col-md-3 col-sm-3 col-xs-12">New password <span class="required">*</span></label>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <input class="form-control col-md-7 col-xs-12" data-toggle="tooltip" data-placement="right" value="<?php echo set_value('password'); ?>" type="password" name="password" id="password" required>
        </div>
    </div>

    <div class="form-group">
        <label for="confirm password" class="control-label col-md-3 col-sm-3 col-xs-12">Confirm password <span class="required">*</span></label>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <input class="form-control col-md-7 col-xs-12" value="<?php echo set_value('confirm_password'); ?>" type="password" name="confirm_password" required>
        </div>
    </div>

    <div class="ln_solid"></div>
    <div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </div>
</form>



