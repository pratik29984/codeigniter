<div class="x_title">
    <h2><i class="fa fa-list"></i> Transaction List</h2>
    <h2 style="float:right"><a class="btn btn-success btn-xs" href="#" onclick="history.back();"> Back</a></h2>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="booking_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Package Name</th>
                    <th>Transaction Id</th>
                    <th>Transaction Amount</th>
                    <th>Transaction Date </th>
                    <th>Action </th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<script>
    $(document).ready(function ()
    {
        $('#booking_table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_transaction/".$this->uri->segment(3))?>',
                type: "post", 
            },
            "aoColumns": [
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": false, "bSortable": false},
            ]
        }).fnSetFilteringDelay(100);
    });
</script>