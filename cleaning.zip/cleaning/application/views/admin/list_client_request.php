<div class="x_title">
    <h2><i class="fa fa-list"></i> Client Booking List</h2>
    <?php if ($this->uri->segment(5) == 'r') { ?><h2 style="float:right"><a href="#" onclick="history.back();"> Back</a></h2><?php } ?>
    <div class="clearfix"></div>
</div>
<div class="x_content">
    <div class="table-responsive">
        <table id="booking_table" class="table table-striped table-bordered bulk_action">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Package Name</th>
                    <th>Booking Date Time</th>
                    <th>Employee</th>
                    <th width="5%">Time (Hours:Minutes:Seconds)</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<script>
    $(document).ready(function ()
    {
        $('#booking_table').dataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                url :'<?php echo base_url("admin/get_client_request/".$this->uri->segment(3))?>',
                type: "post", 
            },
            "aoColumns": [
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
                {"bVisible": true, "bSearchable": true, "bSortable": true},
            ]
        });
    });
</script>